SHAFI'S ROYAL WEDDING INVITATION WEBSITE

HOW TO PREVIEW
1. Extract the ZIP file.
2. Open index.html in Chrome, Edge, or another modern browser.
3. Keep the assets folder beside index.html.

PERSONALISE
Open index.html in a text editor and search for:
- const partnerName = 'Your Forever';
- const weddingDate = null;
Change partnerName to the partner's name. To enable countdown, set weddingDate to an ISO date/time with timezone, e.g. '2027-02-14T19:00:00+05:30'.
- Replace the event date/time/venue copy in the timeline section.
- Update the RSVP button handler to a WhatsApp number or real RSVP form.

ASSETS
The supplied invitation images are used in the event gallery. Note: the supplied invitation artwork itself contains the sample names Aarav and Kiara; replace those images with final personalised artwork before publishing.

DEPLOYMENT
This is a static HTML/CSS/JS site. Upload the folder to static hosting, or deploy it to Vercel/Netlify. Google Fonts requires internet access; fallback fonts are provided.
